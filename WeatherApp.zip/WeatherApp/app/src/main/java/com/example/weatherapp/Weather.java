package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Weather extends AppCompatActivity {

    TextView TemperatureLabel;
    TextView WeatherImage;
    TextView locationText;
    Typeface weatherFont;
    EditText zipcodeText;
    Button searchButton;

    private static String ZIP_CODE = "zip_code";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        TemperatureLabel = findViewById(R.id.TemperatureLabel);
        WeatherImage = findViewById(R.id.WeatherImage);
        locationText = findViewById(R.id.locationText);

        weatherFont = Typeface.createFromAsset(getAssets(), "weathericons-regular-webfont.ttf");
        WeatherImage.setTypeface(weatherFont);

        zipcodeText = findViewById(R.id.zipcodeText);
        searchButton = findViewById(R.id.searchButton);

        // Check if we have saved zip code
        SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
        String zipCode = prefs.getString(ZIP_CODE, null);
        if(zipCode != null){
            UpdateWeather(zipCode);
        }


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String zipCode = zipcodeText.getText().toString();
                UpdateWeather(zipCode);
            }
        });
    }

    //Switch statement, to control which images are shown for rain, cloudy weather, sun etc.
    String getIconForCode(int code){

        if(code ==800)
            return "\uf00d";
        else if(code == 781)
            return "\uf056";

        int hundreds = code / 100;
        switch(hundreds)
        {
            case 2:
                return "\uf005";
            case 3:
                return "\uf00b";
            case 5:
                return "\uf008";
            case 6:
                return "\uf00a";
            case 7:
                return "\uf003";
            case 8:
                return "\uf002";
            default:
                return "\uf041";
        }
    }

    //Calling and parsing the API from OpenWeatherMap into the application, Using JSON to retrieve and translate data
    void UpdateWeather(final String zipCode)
    {
        String apiURL = String.format("https://api.openweathermap.org/data/2.5/weather?zip=%1$s,us&units=imperial&APPID=8ebcbb34d3dacc2359a678e89498d13d", zipCode);

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, apiURL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                // show information on screen, inside a text box
                try {

                    //Get the current temperature formatted correctly in celsius
                    double temp = response.getJSONObject("main").getDouble("temp");
                    String tempFormatted = getString(R.string.temp_format, temp);
                    TemperatureLabel.setText(tempFormatted);


                    //Get icon for current condition of weather
                    int weatherCode = response.getJSONArray("weather").getJSONObject(0).getInt("id");
                    String iconSymbol = getIconForCode(weatherCode);
                    WeatherImage.setText(iconSymbol);

                    //get Location for city by postcode
                    String location = response.getString("name");
                    locationText.setText(location);

                    SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
                    SharedPreferences.Editor prefsEditor = prefs.edit();
                    prefsEditor.putString(ZIP_CODE, zipCode);
                    prefsEditor.apply();

                } catch (JSONException e) {
                    Toast errorToast = Toast.makeText(Weather.this, e.getMessage(), Toast.LENGTH_LONG);
                    errorToast.show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast errorToast = Toast.makeText(Weather.this, error.getMessage(), Toast.LENGTH_LONG);
                errorToast.show();
            }
        });

        queue.add(request);
    }
}
