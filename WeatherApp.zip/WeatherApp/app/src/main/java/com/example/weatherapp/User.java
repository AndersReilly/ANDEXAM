package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class User {
    public String email;
    public String username;
    public String id;


    public User(String email, String username, String id){
        this.email = email;
        this.username = username;
        this.id = id;

    }
}