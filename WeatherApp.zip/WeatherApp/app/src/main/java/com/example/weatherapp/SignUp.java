package com.example.weatherapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {

    private EditText edtMail, edtPassword, edtUsername;
    private Button btnSignUp;
    private FirebaseAuth mAuth;
    private TextView txtLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtLogin = findViewById(R.id.txtLogin);
        mAuth = FirebaseAuth.getInstance();
        edtMail = findViewById(R.id.editTextEmail);
        edtPassword = findViewById(R.id.editTextPassword);
        edtUsername = findViewById(R.id.edtUsername);

        btnSignUp = findViewById(R.id.btnSignUp);

        //If you have a user, you can click here and move to LogIn page
        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (SignUp.this, LogIn.class);
                startActivity(intent);
            }
        });

        //Sign up, and adds the user to the Database for firebase, if not already stored in the DB
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMail.getText().toString().isEmpty() || edtPassword.getText().toString().isEmpty()){
                    Toast.makeText(SignUp.this, "Empty field is not allowed", Toast.LENGTH_SHORT).show();
                    return;}
                mAuth.createUserWithEmailAndPassword(edtMail.getText().toString(), edtPassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    saveUserToDB();
                                    Toast.makeText(SignUp.this, "User Registered", Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(SignUp.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    //Saves the User to the RealTime Database for Firebase
    public void saveUserToDB(){

        DatabaseReference dr = FirebaseDatabase.getInstance().getReference("User/"+edtUsername.getText().toString());
        User newUser = new User(edtMail.getText().toString(), edtUsername.getText().toString(), FirebaseAuth.getInstance().getCurrentUser().getUid());
        dr.setValue(newUser).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SignUp.this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}